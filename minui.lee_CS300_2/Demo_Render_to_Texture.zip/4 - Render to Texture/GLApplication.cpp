// Include standard headers
#include <cstdio>
#include <cstdlib>
#include <vector>
#include <iostream>
#include <cstring>

// Include GLEW
#include <GL/glew.h>

// Include GLFW
#include <GLFW/glfw3.h>

// Nanogui
#include <nanogui/nanogui.h>

// Include GLM
#define GLM_ENABLE_EXPERIMENTAL
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtx/transform.hpp>
#include <fstream>

using namespace glm;

#include "shader.hpp"

#include "../Common/Scene.h"
#include "SimpleScene_OBJ_R2T.h"

// Function declarations
bool savePPMImageFile(std::string &filepath, std::vector<GLfloat> &pixels, int width, int height);
void SetupNanoGUI(GLFWwindow *pWwindow);

//////////////////////////////////////////////////////////////////////
GLFWwindow *mainWindow;
GLFWwindow *nanoWindow;

nanogui::Screen *appScreen = nullptr;

Scene  *scene;

int windowWidth = 1200;
int windowHeight = 1024;

GLfloat normalLength = 0.25f;

///////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////////
int main()
{
    // Initialise GLFW
    if (!glfwInit())
    {
        fprintf(stderr, "Failed to initialize GLFW\n");
        getchar();
        return -1;
    }

//    glfwWindowHint(GLFW_SAMPLES, 4);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 4);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 5);
    glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE); // To make MacOS happy; should not be needed
    glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

    // Open a window and create its OpenGL context
    mainWindow = glfwCreateWindow(windowWidth, windowHeight,
                              "Sample 1 - Simple scene (FBO) with Scene Class",
                              nullptr, nullptr);
    if (mainWindow == nullptr)
    {
        fprintf(stderr,
                "Failed to open GLFW window. If you have an Intel GPU, they are not 4.0 compatible. Try the 2.1 version of the tutorials.\n");
        getchar();
        glfwTerminate();
        return -1;
    }

    // Create the nano gui window
    nanoWindow = glfwCreateWindow(500, 500, "NanoGui", nullptr, mainWindow);
    glfwSetWindowPos(nanoWindow, 0, 0);

    glfwMakeContextCurrent(mainWindow);


    // Initialize GLEW
    glewExperimental = static_cast<GLboolean>(true); // Needed for core profile
    if (glewInit() != GLEW_OK)
    {
        fprintf(stderr, "Failed to initialize GLEW\n");
        getchar();
        glfwTerminate();
        return -1;
    }

    glEnable(GL_DEPTH_TEST);

    // Ensure we can capture the escape key being pressed below
    glfwSetInputMode(mainWindow, GLFW_STICKY_KEYS, GL_TRUE);
    glfwSetInputMode(nanoWindow, GLFW_STICKY_KEYS, GL_TRUE);

    // Initialize the scene
    scene = new SimpleScene_OBJ( windowWidth, windowHeight );

    // Scene::Init encapsulates setting up the geometry and the texture
    // information for the scene
    scene->Init();

    // Set up Nano GUI
    scene->SetupNanoGUI(nanoWindow);

    glfwMakeContextCurrent(mainWindow);


    do
    {
        glfwMakeContextCurrent(nanoWindow);
        glClearColor(0.3f, 0.3f, 0.75f, 1.0f);
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

        // Nano GUI stuff
        // Draw nanogui
        appScreen->drawContents();
        appScreen->drawWidgets();

//        glfwSwapBuffers(nanoWindow);

        // Main window drawing
        glfwMakeContextCurrent(mainWindow);

        // Clear the screen
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

        // Now render the scene
        // Scene::Display method encapsulates pre-, render, and post- rendering operations
        scene->Display();

        // Swap buffers
        glfwSwapBuffers(mainWindow);
        glfwSwapBuffers(nanoWindow);
        glfwPollEvents();

    } // Check if the ESC key was pressed or the mainWindow was closed
    while ((glfwGetKey(mainWindow, GLFW_KEY_ESCAPE) != GLFW_PRESS &&
            glfwWindowShouldClose(mainWindow) == 0) &&
           (glfwGetKey(nanoWindow, GLFW_KEY_ESCAPE) != GLFW_PRESS &&
            glfwWindowShouldClose(nanoWindow) == 0));

    // Close OpenGL window and terminate GLFW
    glfwTerminate();

    return 0;
}

//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////

bool savePPMImageFile(std::string &filepath, std::vector<GLfloat> &pixels, int width, int height)
{
    std::ofstream  texFile(filepath);

    texFile << "P3" << std::endl;
    texFile << width << "  " << height << std::endl;
    texFile << "255" << std::endl;

    auto it = pixels.begin();

    for( int row = 0; row < height; ++row )
    {
        for (int col = 0; col < width; ++col)
        {
            texFile << *it++ << " ";
            texFile << *it++ << " ";
            texFile << *it++ << " ";
        }

        texFile << std::endl;
    }

    texFile.close();

    return true;
}

