//
// Created by pushpak on 3/29/18.
//

#ifndef SAMPLE3_2_FBO_SIMPLESCENE_QUAD_H
#define SAMPLE3_2_FBO_SIMPLESCENE_QUAD_H

#include "Scene.h"
#include "OBJReader.h"
#include <vector>

// Include GLM
#define GLM_ENABLE_EXPERIMENTAL
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtx/transform.hpp>

class SimpleScene_OBJ : public Scene
{
#define GLM_ENABLE_EXPERIMENTAL
public:
    SimpleScene_OBJ();
    SimpleScene_OBJ( int windowWidth, int windowHeight );
    virtual ~SimpleScene_OBJ();


public:
    virtual int Init();
    virtual void CleanUp();

    virtual int Render();
    virtual int postRender();

    // GUI stuff
    bool & getNormalDisplayFlag();
    bool & getDebugRenderFlag();
    void setNormalsDisplay( bool val );

    OBJReader & getObjReader()
    {
        return _objReader;
    }

private:
    // member functions
    void initMembers();

    // Set up buffers for geometry rendering
    void SetupBuffers();
    void SetupFSQ();

    // Set up the FBO for render-to-texture
    bool SetupFBO();
    void UseFBO(int FBO_Handle, int viewportWidth, int viewportHeight);

    // Pass 1 - render to FBO
    int RenderToFBO();

    // Pass 2 - render to FSQ
    int RenderToFSQ();

    // GUI stuff
    bool    bShowNormals = false;
    bool    bDebugFSQ = false;

    // NanoGUI stuff
    virtual void SetupNanoGUI(GLFWwindow *pWwindow);

    // Post Render Operation
    void Update();

    // data members
    GLuint  programID;
    GLuint  FSQProgramID;
    GLuint  vertexbuffers[4];
    GLuint  FSQVertexBuffer;
    GLuint  VertexArrayID;

    GLuint  FBOHandle;
    GLuint  renderedTexture;

    // Replace hardcoded values with OBJ file
    OBJReader  _objReader;
    std::vector<Mesh *>  _sceneMeshes;

    std::vector<GLfloat>    FSQBuffer;

    GLfloat   angleOfRotation;
    GLfloat   theta;
    GLfloat   normalLength;

    void NanoGUI_SetupBasicOperations(nanogui::Screen *pScreen);

    void NanoGUI_SetupShaderParameters(nanogui::Screen *pScreen);

    void SetupUniformBlock();
};


#endif //SAMPLE3_2_FBO_SIMPLESCENE_QUAD_H
