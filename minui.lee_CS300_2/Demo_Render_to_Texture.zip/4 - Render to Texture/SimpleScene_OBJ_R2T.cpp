//
// Created by pushpak on 3/29/18.
//

#include <GL/glew.h>
#include <glm/detail/type_mat.hpp>
#include <iostream>
#include <GLFW/glfw3.h>
#include <nanogui/screen.h>
#include <nanogui/nanogui.h>

#include "SimpleScene_OBJ_R2T.h"
#include "shader.hpp"

// Globals
GLfloat uniform_block[] = {
        1.0f, 1.0f, 2.0f, 0.0f,         // position 0
        -1.0f, 1.0f, 1.0f, 0.0f,         // position 1
        1.0f, 0.0f, 1.0f, 0.0f,        // ambient 0
        0.0f, 0.0f, 1.0f, 0.0f,        // ambient 1
        0.45f, 0.0f, 0.15f, 0.0f,        // diffuse 0
        0.0f, 0.85f, 0.15f, 0.0f,      // diffuse 1
        0.75f, 0.75f, 0.0f, 0.0f,      // specular 0
        0.0f, 0.65f, 0.64f, 0.0f,         // specular 1
};

GLfloat light_position[] = {
        1.0, 1.0, 2.0,
        -1.0, 0.0, 1.0,
};

GLfloat light_color[] = {
        0.81, 0.2, 0.5,
        0.81, 0.2, 0.5,
        0.01, 0.2, 0.5,
        0.25, 0.15, 0.39,
        0.25, 0.15, 0.39,
        1.0, 0.0, 0.0,
};

extern nanogui::Screen *appScreen;

//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
SimpleScene_OBJ::SimpleScene_OBJ() : Scene()
{
    initMembers();
}

//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
SimpleScene_OBJ::SimpleScene_OBJ(int windowWidth, int windowHeight) :
        Scene(windowWidth, windowHeight)
{
    initMembers();
}

//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
void SimpleScene_OBJ::initMembers()
{
    programID = 0;
    FSQProgramID = 0;
    vertexbuffers[0] = 0;
    vertexbuffers[1] = 0;
    VertexArrayID = 0;
    FBOHandle = 0;
    FSQVertexBuffer = 0;

    bDebugFSQ       = false;
    bShowNormals    = false;

    _sceneMeshes.clear();
    angleOfRotation = 0.0f;
    theta = 0.05f;
    normalLength = 0.25f;
}

//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
SimpleScene_OBJ::~SimpleScene_OBJ()
{
    CleanUp();
}

// public methods

//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
// Init
int SimpleScene_OBJ::Init()
{
    // Create and compile our GLSL program from the shaders
    programID = LoadShaders("../../Common/shaders/SimpleVertexShader.vert",
                            "../../Common/shaders/SimpleFragmentShader.frag");

    FSQProgramID = LoadShaders("../FSQ.vert", "../FSQ.frag");

//#define __BENCHMARK__
#ifdef __BENCHMARK__

    double t;

    t += _objReader.ReadOBJFile( "../../Common/models/lucy_princeton.obj" );
    t += _objReader.ReadOBJFile( "../../Common/models/lucy_princeton.obj" );
    t += _objReader.ReadOBJFile( "../../Common/models/lucy_princeton.obj" );
    t += _objReader.ReadOBJFile( "../../Common/models/lucy_princeton.obj" );
    t += _objReader.ReadOBJFile( "../../Common/models/lucy_princeton.obj" );
    t += _objReader.ReadOBJFile( "../../Common/models/lucy_princeton.obj" );
    t += _objReader.ReadOBJFile( "../../Common/models/lucy_princeton.obj" );
    t += _objReader.ReadOBJFile( "../../Common/models/lucy_princeton.obj" );
    t += _objReader.ReadOBJFile( "../../Common/models/lucy_princeton.obj" );
    t += _objReader.ReadOBJFile( "../../Common/models/lucy_princeton.obj" );
    t += _objReader.ReadOBJFile( "../../Common/models/lucy_princeton.obj" );
    t += _objReader.ReadOBJFile( "../../Common/models/lucy_princeton.obj" );

    t /= 12.0;

    std::cout << "[Benchmark timing for OBJ file] : " << t << "  milli seconds \n";

#endif
    _sceneMeshes.push_back( new Mesh() );

//    _objReader.ReadOBJFile( "../../Common/models/sphere.obj", _sceneMeshes[0] );
    _objReader.ReadOBJFile("../../Common/models/lucy_princeton.obj", _sceneMeshes[0]);


    // Enable depth test
    glEnable(GL_DEPTH_TEST);

    // Accept fragment if it closer to the camera than the former one
    glDepthFunc(GL_LESS);

    // Enable face culling
    glEnable(GL_CULL_FACE);


    FSQBuffer = {
            0.0f, 0.0f, 0.0f,       // position
            0.0f, 0.0f,             // uv
            1.0f, 0.0f, 0.0f,
            1.0f, 0.0f,
            0.0f, 1.0f, 0.0f,
            0.0f, 1.0f,
            1.0f, 0.0f, 0.0f,
            1.0f, 0.0f,
            1.0f, 1.0f, 0.0f,
            1.0f, 1.0f,
            0.0f, 1.0f, 0.0f,
            0.0f, 1.0f,
    };

    // set up buffers for rendering
    SetupBuffers();

    // Set up the FBO
    SetupFBO();

    // Setup uniform blocks
    SetupUniformBlock();

    return 0;
}

//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
// CleanUp
void SimpleScene_OBJ::CleanUp()
{
    // Cleanup VBO
    glDeleteBuffers(3, vertexbuffers);
    glDeleteVertexArrays(1, &VertexArrayID);
    glDeleteProgram(programID);
    glDeleteProgram(FSQProgramID);
}

//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
void SimpleScene_OBJ::SetupBuffers()
{
    glGenVertexArrays(1, &VertexArrayID);
    glBindVertexArray(VertexArrayID);

    glGenBuffers(4, vertexbuffers);

    glBindBuffer(GL_ARRAY_BUFFER, vertexbuffers[0]);
    glBufferData(GL_ARRAY_BUFFER, _sceneMeshes[0]->getVertexBufferSize() * sizeof(glm::vec3),
                 _sceneMeshes[0]->getVertexBuffer(), GL_STATIC_DRAW);

    glBindBuffer(GL_ARRAY_BUFFER, vertexbuffers[1]);
    glBufferData(GL_ARRAY_BUFFER, _sceneMeshes[0]->getVertexCount() * sizeof(glm::vec3),
                 _sceneMeshes[0]->getVertexNormals(), GL_STATIC_DRAW);

    glBindBuffer(GL_ARRAY_BUFFER, vertexbuffers[2]);
    glBufferData(GL_ARRAY_BUFFER, _sceneMeshes[0]->getVertexCount() * sizeof(glm::vec3) * 2,
                 _sceneMeshes[0]->getVertexNormalsForDisplay(), GL_STATIC_DRAW);

    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, vertexbuffers[3]);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, _sceneMeshes[0]->getIndexBufferSize() * sizeof(GLuint),
                 _sceneMeshes[0]->getIndexBuffer(), GL_STATIC_DRAW);



    // setup FSQ
    SetupFSQ();

    return;
}
//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
void SimpleScene_OBJ::SetupFSQ()
{
    glGenBuffers( 1, &FSQVertexBuffer );
    glBindBuffer(GL_ARRAY_BUFFER, FSQVertexBuffer);
    glBufferData(GL_ARRAY_BUFFER, FSQBuffer.size() * sizeof(GLfloat),
                 FSQBuffer.data(), GL_STATIC_DRAW);

    return;
}

//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
bool SimpleScene_OBJ::SetupFBO()
{
    glGenFramebuffers(1, &FBOHandle);
    glBindFramebuffer(GL_FRAMEBUFFER, FBOHandle);

// The texture we're going to render to
    glGenTextures(1, &renderedTexture);

// "Bind" the newly created texture : all future texture functions will modify this texture
    glBindTexture(GL_TEXTURE_2D, renderedTexture);

// Give an empty image to OpenGL ( the last "0" means "empty" )
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB,
                 _windowWidth, _windowHeight, 0,
                 GL_RGB, GL_UNSIGNED_BYTE, 0);

// Poor filtering
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);

// The depth buffer
    GLuint depthrenderbuffer;
    glGenRenderbuffers(1, &depthrenderbuffer);
    glBindRenderbuffer(GL_RENDERBUFFER, depthrenderbuffer);
    glRenderbufferStorage(GL_RENDERBUFFER, GL_DEPTH_COMPONENT, _windowWidth, _windowHeight);
    glFramebufferRenderbuffer(GL_FRAMEBUFFER, GL_DEPTH_ATTACHMENT,
                              GL_RENDERBUFFER, depthrenderbuffer);

// Set "renderedTexture" as our colour attachement #0
    glFramebufferTexture(GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT0, renderedTexture, 0);

// Set the list of draw buffers.
    GLenum DrawBuffers[] = {GL_COLOR_ATTACHMENT0, GL_DEPTH_ATTACHMENT};
    glDrawBuffers(2, DrawBuffers); // "2" is the size of DrawBuffers

// Always check that our framebuffer is ok
    return glCheckFramebufferStatus(GL_FRAMEBUFFER) == GL_FRAMEBUFFER_COMPLETE;
}

//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
// Render : per frame rendering of the scene
int SimpleScene_OBJ::Render()
{
    // Pass 1 - render to FBO
    RenderToFBO();

    // Pass 2 - render to FSQ
    if( bDebugFSQ == false)
        RenderToFSQ();

    return 0;
}

//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
int SimpleScene_OBJ::RenderToFBO()
{
    // Use this for debug - if you want to see what is being rendered into the texture on the screen
    if( bDebugFSQ == false)
        UseFBO(FBOHandle, _windowWidth, _windowHeight);
    else
        UseFBO(0, _windowWidth, _windowHeight);

    // Backface culling - for Lucy model - normals are flipped
    glCullFace(GL_FRONT);
    glFrontFace(GL_CCW);

    // Clear the screen
    glClearColor(0.2f, 0.2f, 0.2f, 1.0f);

    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    // Use our shader
    glUseProgram(programID);

    // 1st attribute buffer : vertex positions (model space)
    glEnableVertexAttribArray(0);

    glBindBuffer(GL_ARRAY_BUFFER, vertexbuffers[0]);
    glVertexAttribPointer(
            0,                  // attribute 0. MUST match the layout in the shader.
            3,                  // size
            GL_FLOAT,           // type
            GL_FALSE,           // normalized?
            0,                 // stride ( sizeof(GLfloat) * 9 )
            (void *) 0          // array buffer offset in bytes - first byte
    );

    // 2nd attribute buffer : vertex normals
    glEnableVertexAttribArray(1);

    glBindBuffer(GL_ARRAY_BUFFER, vertexbuffers[1]);
    glVertexAttribPointer(
            1,                  // attribute 1. MUST match the layout in the shader.
            3,                  // size
            GL_FLOAT,           // type
            GL_TRUE,           // normalized?
            0,                 // stride ( sizeof(GLfloat) * 9 )
            (void *) 0         // array buffer offset in bytes - sizeof(GLfloat) * 6
    );
//
//    // 3rd attribute buffer : vertex colors (model space)
//    glEnableVertexAttribArray(2);
//
//    glBindBuffer(GL_ARRAY_BUFFER, vertexbuffers[0]);
//    glVertexAttribPointer(
//            2,                  // attribute 2. MUST match the layout in the shader.
//            3,                  // size
//            GL_FLOAT,           // type
//            GL_TRUE,            // normalized?
//            36,                 // stride
//            (void *) 12         // array buffer offset - sizeof(GLfloat) * 3
//    );
//
//    // 4th attribute buffer : vertex UVs (model space)
//    glEnableVertexAttribArray(3);
//
//    glBindBuffer(GL_ARRAY_BUFFER, vertexbuffers[0]);
//    glVertexAttribPointer(
//            3,                  // attribute 3. MUST match the layout in the shader.
//            2,                  // size
//            GL_FLOAT,           // type
//            GL_TRUE,            // normalized?
//            36,                 // stride
//            (void *) 28         // array buffer offset - sizeof(GLfloat) * 3
//    );

    // Uniform transformation (vertex shader)
    GLint vTransformLoc = glGetUniformLocation(programID, "vertexTransform");

    // Draw the triangle !
    // T * R * S * Vertex
    glm::mat4 modelMat = glm::mat4(1.0f);
    glm::vec3 scaleVector = 1.0f / _sceneMeshes[0]->getModelScale();
    glm::vec3 centroid = -1.0f * _sceneMeshes[0]->getModelCentroid();
    modelMat = //glm::translate( glm::vec3(-0.5f, -0.5f, 0.0f ) ) *
               glm::rotate(angleOfRotation, glm::vec3(1.0f, 1.0f, 1.0f)) *
               glm::scale( scaleVector ) *
               glm::translate( centroid );

    glUniformMatrix4fv(vTransformLoc, 1, GL_FALSE, &modelMat[0][0]);

    // Normal transform
    GLint normalMatLoc = glGetUniformLocation(programID, "normalTransform");
    glm::mat4 normalMat = glm::transpose( glm::inverse(modelMat));
    glUniformMatrix4fv(normalMatLoc, 1, GL_FALSE, &normalMat[0][0]);

    // Shininess value (uniform variable)
    GLint shiniLoc = glGetUniformLocation(programID, "shininess");
    glUniform1f(shiniLoc, 20.0);


    glDrawElements(GL_TRIANGLES,
                   _sceneMeshes[0]->getIndexBufferSize(),
                   GL_UNSIGNED_INT,
                   nullptr);

    glDisableVertexAttribArray(0);
    glDisableVertexAttribArray(1);
//    glDisableVertexAttribArray(2);
//    glDisableVertexAttribArray(3);

    if( bShowNormals )
    {
        // 1st attribute buffer : vertex positions (model space)
        glEnableVertexAttribArray(0);

        glBindBuffer(GL_ARRAY_BUFFER, vertexbuffers[2]);
        glVertexAttribPointer(
                0,                  // attribute 0. MUST match the layout in the shader.
                3,                  // size
                GL_FLOAT,           // type
                GL_FALSE,           // normalized?
                0,                 // stride ( sizeof(GLfloat) * 9 )
                (void *) 0          // array buffer offset in bytes - first byte
        );

        glDrawArrays(GL_LINES, 0, _sceneMeshes[0]->getVertexCount() );

        glDisableVertexAttribArray(0);
    }

    return 0;
}

//////////////////////////////////////////////////////
//////////////////////////////////////////////////////
int SimpleScene_OBJ::RenderToFSQ()
{
    UseFBO(0, _windowWidth, _windowHeight);

    // Revert to usual culling behavior
    glCullFace(GL_BACK);
    glFrontFace(GL_CCW);

    // Clear the screen
    glClearColor(0.0f, 0.0f, 0.0f, 1.0f);

    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    // Use our shader
    glUseProgram(FSQProgramID);

    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, renderedTexture);

    // 1st attribute buffer : vertex positions (model space)
    glEnableVertexAttribArray(0);

    glBindBuffer(GL_ARRAY_BUFFER, FSQVertexBuffer);
    glVertexAttribPointer(
            0,                        // attribute 0. MUST match the layout in the shader.
            3,                        // size
            GL_FLOAT,                 // type
            GL_FALSE,                 // normalized?
            5 * sizeof(GLfloat),      // stride ( sizeof(GLfloat) * 9 )
            (void *) nullptr          // array buffer offset in bytes - first byte
    );

    // 2nd attribute buffer : vertex UV
    glEnableVertexAttribArray(1);

    glBindBuffer(GL_ARRAY_BUFFER, FSQVertexBuffer);

    glVertexAttribPointer(
            1,                        // attribute 3. MUST match the layout in the shader.
            2,                        // size
            GL_FLOAT,                 // type
            GL_TRUE,                  // normalized?
            5 * sizeof(GLfloat),      // stride
            (void *) 12               // array buffer offset - sizeof(GLfloat) * 3
    );

    GLint texLocation = glGetUniformLocation(FSQProgramID, "texSampler");
    glUniform1i(texLocation, 0);

    // Uniform transformation (vertex shader)
    GLint vTransformLoc = glGetUniformLocation(FSQProgramID, "vertexTransform");

    // Draw the triangle !
    // T * R * S * Vertex
    glm::mat4 modelMat = glm::mat4(1.0f);

    modelMat = glm::rotate(-angleOfRotation * 0.5f, glm::vec3(0.0f, 1.0f, 1.0f)) *
               glm::translate(glm::vec3(-0.5f, -0.5f, 0.0f));

    glUniformMatrix4fv(vTransformLoc, 1, GL_FALSE, &modelMat[0][0]);


    glDrawArrays(GL_TRIANGLES, 0, 6); // 3 indices starting at 0 -> 1 triangle

    glDisableVertexAttribArray(0);
    glDisableVertexAttribArray(1);

    return 0;
}

////////////////////////////////////////////////
////////////////////////////////////////////////
////////////////////////////////////////////////
int SimpleScene_OBJ::postRender()
{
    angleOfRotation += 0.01f;

    Update();

    return 0;
}

////////////////////////////////////////////////
////////////////////////////////////////////////
////////////////////////////////////////////////
void SimpleScene_OBJ::UseFBO(int FBO_Handle, int viewportWidth, int viewportHeight)
{
    glBindFramebuffer(GL_FRAMEBUFFER, FBO_Handle);

    if (glCheckFramebufferStatus(GL_FRAMEBUFFER) != GL_FRAMEBUFFER_COMPLETE)
    {
        std::cout << "[UseFBO] Cannot switch to FBO - " << FBO_Handle << std::endl;
        std::cout << "[UseFBO] FBO not complete" << std::endl;
        return;
    }

    glViewport(0, 0, viewportWidth, viewportHeight);
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    return;
}

///////////////////////////////////////////////////////
//////////////////////////////////////////////////////

bool & SimpleScene_OBJ::getNormalDisplayFlag()
{
    return bShowNormals;
}

///////////////////////////////////////////////////////
//////////////////////////////////////////////////////

bool & SimpleScene_OBJ::getDebugRenderFlag()
{
    return bDebugFSQ;
}

///////////////////////////////////////////////////////
//////////////////////////////////////////////////////

void SimpleScene_OBJ::setNormalsDisplay( bool val )
{
    bShowNormals = val;
}

///////////////////////////////////////////////////////
//////////////////////////////////////////////////////
/////////////////////////////////////////////////////
/////////////////////////////////////////////////////
void SimpleScene_OBJ::SetupNanoGUI(GLFWwindow *pWwindow)
{
    glfwMakeContextCurrent(pWwindow);

    glClearColor(0.3f, 0.3f, 0.75f, 1.0f);
    glClear(GL_COLOR_BUFFER_BIT);

    // Create a nanogui myScreen and pass the glfw pointer to initialize
    appScreen = new nanogui::Screen();

    appScreen->initialize(pWwindow, true);

    bool enabled = true;
    nanogui::FormHelper *guiForm = new nanogui::FormHelper(appScreen);
    nanogui::ref<nanogui::Window> nanoguiWindow = guiForm->addWindow(Eigen::Vector2i(10, 10), "Control Window");


    guiForm->addGroup("Basic Parameters");
    guiForm->addVariable( "Show Normals?", getNormalDisplayFlag() );
    guiForm->addVariable( "Disable Render-to-texture", getDebugRenderFlag() );
    nanogui::detail::FormWidget<float>  *nLength = guiForm->addVariable( "Normal length",
            normalLength );
    nLength->setDefaultValue("0.25f");

    appScreen->setVisible(true);
    appScreen->performLayout();
    nanoguiWindow->center();

    glfwSetCursorPosCallback(pWwindow,
                             [](GLFWwindow *, double x, double y)
                             {
                                 appScreen->cursorPosCallbackEvent(x, y);
                             }
    );

    glfwSetMouseButtonCallback(pWwindow,
                               [](GLFWwindow *, int button, int action, int modifiers)
                               {
                                   appScreen->mouseButtonCallbackEvent(button, action, modifiers);
                               }
    );

    glfwSetKeyCallback(pWwindow,
                       [](GLFWwindow *, int key, int scancode, int action, int mods)
                       {
                           appScreen->keyCallbackEvent(key, scancode, action, mods);
                       }
    );

    glfwSetCharCallback(pWwindow,
                        [](GLFWwindow *, unsigned int codepoint)
                        {
                            appScreen->charCallbackEvent(codepoint);
                        }
    );

    glfwSetDropCallback(pWwindow,
                        [](GLFWwindow *, int count, const char **filenames)
                        {
                            appScreen->dropCallbackEvent(count, filenames);
                        }
    );

    glfwSetScrollCallback(pWwindow,
                          [](GLFWwindow *, double x, double y)
                          {
                              appScreen->scrollCallbackEvent(x, y);
                          }
    );

    glfwSetFramebufferSizeCallback(pWwindow,
                                   [](GLFWwindow *, int width, int height)
                                   {
                                       appScreen->resizeCallbackEvent(width, height);
                                   }
    );

    // force refresh
    glfwSwapBuffers(pWwindow);

}

////////////////////////////////////////////////
////////////////////////////////////////////////
////////////////////////////////////////////////
void SimpleScene_OBJ::Update()
{
    // Light 0
    GLfloat radius = 20.0f;

    GLfloat theta_R;
    theta_R = static_cast<GLfloat>(theta / M_1_PI);
    uniform_block[0] = radius * cosf(theta_R);
    uniform_block[2] = radius * sinf(theta_R);
//    light_position[0] = radius * cosf(theta_R);
//    light_position[2] = radius * sinf(theta_R);

    uniform_block[4] = radius * cosf(theta_R * 0.75f);
    uniform_block[5] = radius * sinf(theta_R * 0.75f);
//    light_position[4] = radius * cosf(theta_R * 0.5f);
//    light_position[5] = radius * sinf(theta_R * 0.5f);

    theta += 0.005;

    if( theta >= 359.50 )
        theta = 0.5;

    return;
}

void SimpleScene_OBJ::NanoGUI_SetupBasicOperations(nanogui::Screen *pScreen)
{};

void SimpleScene_OBJ::NanoGUI_SetupShaderParameters(nanogui::Screen *pScreen)
{}

void SimpleScene_OBJ::SetupUniformBlock()
{
    // Uniform block
    // Uniform block (fragment shader)
    GLuint uboIndex;
    GLint uboSize;
    GLubyte *buffer = nullptr;

    GLuint indices[4];
    GLint offset[4];
    const GLchar *names[] = {
            "LightArray.LightPosition",
            "LightArray.LightAmbient",
            "LightArray.LightDiffuse",
            "LightArray.LightSpecular"
    };

    // Step 1. Get the block index
    uboIndex = glGetUniformBlockIndex(programID, "LightArray");
    if (uboIndex != GL_INVALID_INDEX)
    {

        // Step 2. Get the block size
        glGetActiveUniformBlockiv(programID,
                                  uboIndex,
                                  GL_UNIFORM_BLOCK_DATA_SIZE,
                                  &uboSize);

//            std::cout << "Uniform block ID: " << uboIndex << std::endl;
//            std::cout << "Uniform block size: " << uboSize << std::endl;

        // Step 3. Allocate the block
        buffer = new GLubyte[uboSize];

        // Step 4. Get the block indices
        // Names must be qualified by block name (Outside GLSL)
        glGetUniformIndices(programID, 4, names, indices);

//            std::cout << "Indices : " << names[0] << ", " << indices[0] << std::endl;
//            std::cout << "Indices : " << names[1] << ", " << indices[1] << std::endl;
//            std::cout << "Indices : " << names[2] << ", " << indices[2] << std::endl;
//            std::cout << "Indices : " << names[3] << ", " << indices[3] << std::endl;


        glGetActiveUniformsiv(programID, 4, indices,
                              GL_UNIFORM_OFFSET, offset);

//            std::cout << "Offset : " << names[0] << ", " << offset[0] << std::endl;
//            std::cout << "Offset : " << names[1] << ", " << offset[1] << std::endl;
//            std::cout << "Offset : " << names[2] << ", " << offset[2] << std::endl;
//            std::cout << "Offset : " << names[3] << ", " << offset[3] << std::endl;

        // Step 5. Copy the data over
        buffer = (GLubyte *) std::memcpy(buffer, uniform_block, sizeof(uniform_block));

//        std::memcpy(buffer + offset[1], light_color, sizeof(light_color) );

        // Step 6. Create OpenGL Buffer object and bind data into it
        GLuint uboHandle;
        glGenBuffers(1, &uboHandle);
        glBindBuffer(GL_UNIFORM_BUFFER, uboHandle);
        glBufferData(GL_UNIFORM_BUFFER, uboSize, buffer,
                     GL_DYNAMIC_DRAW);

        // Step 7. Bind the base of the buffer
        glBindBufferBase(GL_UNIFORM_BUFFER, uboIndex, uboHandle);

    }

    if (buffer)
        delete[] buffer;
};